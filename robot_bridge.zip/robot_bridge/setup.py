from setuptools import setup

package_name = 'robot_bridge'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='avneet',
    maintainer_email='avneet@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
        'robot_bridge = robot_bridge.robot_bridge:main',
        'keyboard_controller = robot_bridge.keyboard_controller:main',
        'keyboard_controller2 = robot_bridge.keyboard_controller2:main',
        'scared_robot= robot_bridge.scared_robot:main',
        'subsumption= robot_bridge.subsumption:main',
        'gui= robot_bridge.gui:main'
        ],
    },
)
