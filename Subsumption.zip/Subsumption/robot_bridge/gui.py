import rclpy
from rclpy.node import Node
from std_msgs.msg import String

from pynput import keyboard
import getpass
import pygame
import pygame_gui
from pygame.locals import *
import time
class KeyboardController(Node):
    
     def listener_callback(self, msg):
          msg = String()
          RED = (255, 0, 0)
          pygame.init()
          pygame.display.set_caption('Robot GUI')
          window_surface = pygame.display.set_mode((800,600))
          background = pygame.Surface((800, 600))
          background.fill(pygame.Color('#000000'))
          manager = pygame_gui.UIManager((800, 600))
          LAYER1_button = pygame_gui.elements.UIButton(relative_rect=pygame.Rect((400,0), (115, 50)),text='LAYER1',manager=manager)
          LAYER2_button = pygame_gui.elements.UIButton(relative_rect=pygame.Rect((400,75), (115, 50)),text='LAYER2',manager=manager)
          LAYER3_button = pygame_gui.elements.UIButton(relative_rect=pygame.Rect((400,150), (115, 50)),text='LAYER3',manager=manager)
          LAYER4_button = pygame_gui.elements.UIButton(relative_rect=pygame.Rect((400,235), (115, 50)),text='LAYER4',manager=manager)
          quit_button = pygame_gui.elements.UIButton(relative_rect=pygame.Rect((250,500), (200,50)),text='Quit',manager=manager)
          clock = pygame.time.Clock()
          is_running = True
 
          while is_running:
              time_delta = clock.tick(60)/1000.0
              for event in pygame.event.get():
                  if event.type == pygame.USEREVENT:
                      if event.user_type == pygame_gui.UI_BUTTON_PRESSED:
                          if event.ui_element == quit_button:
                              is_running = False
                  if event.type == pygame.USEREVENT:
                      if event.user_type == pygame_gui.UI_BUTTON_PRESSED:
                          if event.ui_element == LAYER1_button:
                              msg.data = "MOVEF:1000"
                              self.publisher.publish(msg)
                              msg.data = "STOP:0000"
                              self.publisher.publish(msg)
                  if event.type == pygame.USEREVENT:
                      if event.user_type == pygame_gui.UI_BUTTON_PRESSED:
                          if event.ui_element == LAYER3_button:
                              msg.data = "TURNR:1000"
                              self.publisher.publish(msg)
                              msg.data = "TURNL:1000"
                              self.publisher.publish(msg)
                  if event.type == pygame.USEREVENT:
                      if event.user_type == pygame_gui.UI_BUTTON_PRESSED:
                          if event.ui_element == LAYER2_button:
                              msg.data = "MOVEB:1000"
                              self.publisher.publish(msg)
                  if event.type == pygame.USEREVENT:
                      if event.user_type == pygame_gui.UI_BUTTON_PRESSED:
                          if event.ui_element == LAYER4_button:
                              msg.data = "TURNR:0100"
                              self.publisher.publish(msg)
                  
                 
                  manager.process_events(event)
                  
              manager.update(time_delta)
              window_surface.blit(background, (0, 0))
              manager.draw_ui(window_surface)
              pygame.display.update()

     def __init__(self):
          super().__init__('KeyboardController')
          self.publisher = self.create_publisher(String, '/robot/control', 10)
          self.subscription = self.create_subscription(
            String,
            '/robot/right',
            self.listener_callback,
            10)
          self.subscription  # prevent unused variable warning
       
         
def main(args=None):
    rclpy.init(args=args)

    controller = KeyboardController()
    rclpy.spin(controller)

    controller.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
